package org.codehaus.groovy.grails.plugins.searchable.test.domain.nosearchableproperty

// A Groovy domain class without a "searchable" property
class NoSearchableProperty {
    Long id
    Long version
    String desscription
}
