package org.codehaus.groovy.grails.plugins.searchable.test.domain.inheritance

class SearchableGrandChild extends SearchableChildOne {
    Long id
    Long version
    String grandChildProperty
}
