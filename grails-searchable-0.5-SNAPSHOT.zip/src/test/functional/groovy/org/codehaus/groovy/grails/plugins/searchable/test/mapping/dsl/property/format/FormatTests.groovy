/*
 * Copyright 2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.codehaus.groovy.grails.plugins.searchable.test.mapping.dsl.property.format

import org.codehaus.groovy.grails.plugins.searchable.test.SearchableFunctionalTestCase
import java.text.SimpleDateFormat
import org.compass.core.Resource

/**
 * @author Maurice Nicholson
 */
class FormatTests extends SearchableFunctionalTestCase {

    public getDomainClasses() {
        return [A]
    }

    void testFormat() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd")
        def date = format.parse("2008-08-15")
        new A(id: 1l, value: date).index()

        def a = A.searchTop("2008-08-15")
        assert a
        assert format.format(a.value) == "2008-08-15"
    }
}
