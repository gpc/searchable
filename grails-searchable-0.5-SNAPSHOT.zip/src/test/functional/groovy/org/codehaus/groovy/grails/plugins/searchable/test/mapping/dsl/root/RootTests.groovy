/*
 * Copyright 2008 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.codehaus.groovy.grails.plugins.searchable.test.mapping.dsl.root

import org.codehaus.groovy.grails.plugins.searchable.test.SearchableFunctionalTestCase

/**
 * @author Maurice Nicholson
 */
class RootTests extends SearchableFunctionalTestCase {
    def searchableService

    public getDomainClasses() {
        return [Root, NonRoot]
    }
    
    void testRoot() {
        def root = new Root(id: 1L, value: "value")
        def nonRoot = new NonRoot(id: 1L, value: "value")
        root.nonRoot = nonRoot
        root.index()
//        template.save(nonRoot)

        def roots = searchableService.searchEvery("value")
        assert roots.size() == 1, roots.size()
        assert roots[0] instanceof Root
        assert roots[0].nonRoot
    }
}